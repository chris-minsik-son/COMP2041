#!/bin/dash

if test Andrew = great
then
    echo correct
else
    echo error
fi
