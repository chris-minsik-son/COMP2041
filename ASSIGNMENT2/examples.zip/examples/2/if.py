#!/usr/bin/python3 -u

if 'Andrew' == 'great':
    print('correct')
else:
    print('error')
