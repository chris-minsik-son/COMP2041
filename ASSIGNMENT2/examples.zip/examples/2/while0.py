#!/usr/bin/python3 -u

status = 'off'
while status != 'on':
    print(f'status is {status}')
    status = 'on'
