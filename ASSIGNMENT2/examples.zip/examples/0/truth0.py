#!/usr/bin/python3 -u

print('And I told you to be patient')
print('And I told you to be fine')
print('And I told you to be balanced')
print('And I told you to be kind')
