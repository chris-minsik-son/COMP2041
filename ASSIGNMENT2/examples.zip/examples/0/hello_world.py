#!/usr/bin/python3 -u

print('hello world')
