#!/bin/dash

a=hello
b=world

echo $a $b
