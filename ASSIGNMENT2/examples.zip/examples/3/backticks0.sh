#!/bin/dash

a=`printf hi`
echo $a
