#!/usr/bin/python3 -u
import os
import subprocess

os.chdir('/tmp')
subprocess.run(['pwd'])
