#!/usr/bin/python3 -u

import subprocess

subprocess.run(['ls', '/dev/null'])
