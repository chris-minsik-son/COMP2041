#!/usr/bin/python3 -u

for n in ['one', 'two', 'three']:
    line = input()
    print(f"Line {n} {line}")
