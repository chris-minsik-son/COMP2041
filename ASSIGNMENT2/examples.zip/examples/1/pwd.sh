#!/bin/dash

pwd
