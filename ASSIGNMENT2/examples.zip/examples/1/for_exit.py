#!/usr/bin/python3 -u

import sys

for word in ['Houston', '1202', 'alarm']:
    print(word)
    sys.exit(0)
