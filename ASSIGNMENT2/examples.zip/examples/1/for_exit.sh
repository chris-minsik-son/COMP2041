#!/bin/dash

for word in Houston 1202 alarm
do
    echo $word
    exit 0
done
