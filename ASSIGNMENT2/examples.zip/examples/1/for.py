#!/usr/bin/python3 -u

for word in 'Houston', '1202', 'alarm':
    print(word)
