#!/usr/bin/python3 -u

import subprocess

subprocess.run(['pwd'])
subprocess.run(['ls'])
subprocess.run(['id'])
subprocess.run(['date'])
